# Contributing to PAIT

PAIT adalah project yang bs di remote sehinnga menerima anda yang akan menjadi kontributor daro komunitas ini [Contributing to PAIT](./contributing/README.md).
